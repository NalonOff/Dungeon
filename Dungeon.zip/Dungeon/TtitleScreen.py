import pygame
import Scene
from HeroSelecterScreen import HeroSelecterScreen
from MaskedOrc import MaskedOrc

class TitleScreen(Scene.Scene):

    def __init__(self, screen):
        super().__init__(screen)
        self.heroselecter = HeroSelecterScreen(screen)

        self.masked_orc = MaskedOrc()
        self.masked_orc.pos = [300, 120]

        self.playButton = pygame.image.load('assets/textures/gui/TitleScreen/startButtonBlack.png')
        self.playButtonRect = pygame.Rect(196, 320, 246, 106)
        self.back = pygame.image.load('assets/textures/gui/TitleScreen/back.png')

        self.started = False

    def handling_event(self):

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if self.playButtonRect.collidepoint(pygame.mouse.get_pos()):
                self.playButton = pygame.image.load('assets/textures/gui/TitleScreen/startButtonWhite.png')
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.started = True
            else:
                self.playButton = self.playButton = pygame.image.load('assets/textures/gui/TitleScreen/startButtonBlack.png')

        self.clock.tick(120)

    def start_game(self):
        self.masked_orc.moving_right = True
        start_Rect = pygame.Rect(430, 120, 16, 27)

        if self.masked_orc.rect.colliderect(start_Rect):
            self.masked_orc.moving_right = False
            self.running = False
            self.heroselecter.run()

    def update(self):
        self.masked_orc.update()

        if self.started:
            self.start_game()

    def run(self):
        while self.running:
            self.handling_event()
            self.update()

            self.screen.fill((34, 34, 34))
            self.display.fill((0, 0, 0))

            self.display.blit(self.back, (0, 0))
            self.display.blit(self.playButton, (98, 160))
            self.display.blit(self.masked_orc.image, self.masked_orc.pos)

            self.display_flip()

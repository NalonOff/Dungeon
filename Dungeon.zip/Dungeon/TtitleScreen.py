import pygame
from Game import Game
from MaskedOrc import MaskedOrc

class TitleScreen:

    def __init__(self, screen):
        self.screen = screen
        self.display = pygame.Surface((512, 288))
        self.running = True
        self.started = False
        self.clock = pygame.time.Clock()

        self.game = Game(self.screen)

        self.masked_orc = MaskedOrc()
        self.masked_orc.pos = [275, 120]

        self.playButton = pygame.image.load('assets/textures/gui/StartButtonBlack.png')
        self.back = pygame.image.load('assets/textures/gui/TitleScreenBackground.png')

        self.playButtonRect = pygame.Rect(196, 320, 246, 106)

    def handling_event(self):

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if self.playButtonRect.collidepoint(pygame.mouse.get_pos()):
                self.playButton = pygame.image.load('assets/textures/gui/StartButtonWhite.png')
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.started = True
            else:
                self.playButton = self.playButton = pygame.image.load('assets/textures/gui/StartButtonBlack.png')

        self.clock.tick(120)

    def start_game(self):
        self.masked_orc.moving_right = True
        start_Rect = pygame.Rect(430, 120, 16, 27)

        if self.masked_orc.rect.colliderect(start_Rect):
            self.running = False
            self.game.run()

    def update(self):
        self.masked_orc.update()

        if self.started:
            self.start_game()

    def run(self):
        while self.running:
            self.handling_event()
            self.update()

            self.screen.fill((34, 34, 34))
            self.display.fill((0, 0, 0))

            self.display.blit(self.back, (0, 0))
            self.display.blit(self.playButton, (98, 160))
            self.display.blit(self.masked_orc.image, self.masked_orc.pos)

            self.surf = pygame.transform.scale(self.display, (1024, 576))
            self.screen.blit(self.surf, (0, 0))

            pygame.display.flip()

import Entity

class Zombie(Entity.Entity):

    def __init__(self):
        super().__init__('zombie')

        self.health = 20
        self.attack = 3

        self.pos = [20, 30]

    def damage(self, amount):
        if self.health - amount > amount:
            self.health -= amount

    def update_animation(self, action, way):
        self.animate(action, way)

    def update(self):
        if self.moving_left == False and self.moving_right == False and self.moving_left == False and self.moving_right == False:
            self.update_animation('idle', self.lastWay)

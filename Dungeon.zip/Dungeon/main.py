import pygame
from TtitleScreen import TitleScreen

pygame.init()
pygame.display.set_caption('Dongeon - DarkSide', 'assets/textures/entity/necromancer/necromancer_idle_anim_f1.png')
pygame.display.set_icon(pygame.image.load('assets/textures/entity/necromancer/necromancer_idle_anim_f1.png'))
screen = pygame.display.set_mode((852, 480))

titlescreen = TitleScreen(screen)
titlescreen.run()

pygame.quit()

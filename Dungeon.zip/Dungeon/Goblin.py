import Entity

class Goblin(Entity.Entity):

    def __init__(self):
        super().__init__('goblin')

        self.health = 5
        self.attack = 1

        self.pos = [30, 20]
        self.velocity = 1

    def damage(self, amount):
        if self.health - amount > amount:
            self.health -= amount

    def update_animation(self, action, way):
        self.animate(action, way)

    def update(self):
        if self.moving_left == False and self.moving_right == False and self.moving_left == False and self.moving_right == False:
            self.update_animation('idle', self.lastWay)

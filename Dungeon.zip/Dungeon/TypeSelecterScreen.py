import pygame
import Scene
from Game import Game
from ElfM import ElfM
from WizzardM import WizzardM
from KnightM import KnightM
from ElfF import ElfF
from WizzardF import WizzardF
from KnightF import KnightF

class TypeSelecterScreen(Scene.Scene):

    def __init__(self, screen):
        super().__init__(screen)
        self.game = Game(screen)

        self.selectButtonLeft = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonBlack.png')
        self.selectButtonRight = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonBlack.png')

        self.selectButtonLeftRect = pygame.Rect(32, 180, 224, 224)
        self.selectButtonRightRect = pygame.Rect(616, 180, 224, 224)

        self.back = pygame.image.load('assets/textures/gui/SelectTypeScreen/back.png')

        self.elf_m = ElfM()
        self.wizzard_m = WizzardM()
        self.knight_m = KnightM()

        self.elf_f = ElfF()
        self.wizzard_f = WizzardF()
        self.knight_f = KnightF()

        self.started = False


    def handling_event(self):

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if self.selectButtonLeftRect.collidepoint(pygame.mouse.get_pos()):
                self.selectButtonLeft = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonWhite.png')
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.game.run()
                    self.running = False
            elif self.selectButtonRightRect.collidepoint(pygame.mouse.get_pos()):
                self.selectButtonRight = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonWhite.png')
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.game.run()
                    self.running = False
            else:
                self.selectButtonLeft = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonBlack.png')
                self.selectButtonRight = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonBlack.png')

        self.clock.tick(120)


    def update(self):
        self.elf_m.update()
        self.elf_f.update()
        self.wizzard_m.update()
        self.wizzard_f.update()
        self.knight_m.update()
        self.knight_f.update()


    def load_hero(self, hero):
        if hero == 'elf':
            self.display.blit(self.zoom(self.elf_f.image, 3), (40, 75))
            self.display.blit(self.zoom(self.elf_m.image, 3), (330, 75))
        elif hero == 'wizzard':
            self.display.blit(self.zoom(self.wizzard_f.image, 3), (40, 75))
            self.display.blit(self.zoom(self.wizzard_m.image, 3), (330, 75))
        elif hero == 'knight':
            self.display.blit(self.zoom(self.knight_f.image, 3), (40, 75))
            self.display.blit(self.zoom(self.knight_m.image, 3), (330, 75))


    def run(self, hero):
        while self.running:
            self.handling_event()
            self.update()

            self.screen.fill((34, 34, 34))
            self.display.fill((0, 0, 0))

            self.display.blit(self.back, (0, 0))
            self.display.blit(self.selectButtonLeft, (16, 90))
            self.display.blit(self.selectButtonRight, (308, 90))

            self.load_hero(hero)

            self.display_flip()

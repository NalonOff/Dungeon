import pygame
import Scene
from TypeSelecterScreen import TypeSelecterScreen
from ElfM import ElfM
from WizzardM import WizzardM
from KnightM import KnightM

class HeroSelecterScreen(Scene.Scene):

    def __init__(self, screen):
        super().__init__(screen)
        self.genderSelecterScreen = TypeSelecterScreen(screen)

        self.selectButtonLeft = pygame.image.load('assets/textures/gui/SelectHeroScreen/selectButtonBlack.png')
        self.selectButtonMid = pygame.image.load('assets/textures/gui/SelectHeroScreen/selectButtonBlack.png')
        self.selectButtonRight = pygame.image.load('assets/textures/gui/SelectHeroScreen/selectButtonBlack.png')

        self.selectButtonLeftRect = pygame.Rect(36, 220, 224, 224)
        self.selectButtonMidRect = pygame.Rect(316, 220, 224, 224)
        self.selectButtonRightRect = pygame.Rect(596, 220, 224, 224)

        self.back = pygame.image.load('assets/textures/gui/SelectHeroScreen/back.png')

        self.elf = ElfM()
        self.wizzard = WizzardM()
        self.knight = KnightM()


    def handling_event(self):

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if self.selectButtonLeftRect.collidepoint(pygame.mouse.get_pos()):
                self.selectButtonLeft = pygame.image.load('assets/textures/gui/SelectHeroScreen/selectButtonWhite.png')
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.genderSelecterScreen.run('elf')
                    self.running = False
            elif self.selectButtonMidRect.collidepoint(pygame.mouse.get_pos()):
                self.selectButtonMid = pygame.image.load('assets/textures/gui/SelectHeroScreen/selectButtonWhite.png')
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.genderSelecterScreen.run('wizzard')
                    self.running = False
            elif self.selectButtonRightRect.collidepoint(pygame.mouse.get_pos()):
                self.selectButtonRight = pygame.image.load('assets/textures/gui/SelectHeroScreen/selectButtonWhite.png')
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.genderSelecterScreen.run('knight')
                    self.running = False
            else:
                self.selectButtonLeft = pygame.image.load('assets/textures/gui/SelectHeroScreen/selectButtonBlack.png')
                self.selectButtonMid = pygame.image.load('assets/textures/gui/SelectHeroScreen/selectButtonBlack.png')
                self.selectButtonRight = pygame.image.load('assets/textures/gui/SelectHeroScreen/selectButtonBlack.png')

        self.clock.tick(120)


    def update(self):
        self.elf.update()
        self.wizzard.update()
        self.knight.update()


    def run(self):
        while self.running:
            self.handling_event()
            self.update()

            self.screen.fill((34, 34, 34))
            self.display.fill((0, 0, 0))

            self.display.blit(self.back, (0, 0))
            self.display.blit(self.selectButtonLeft, (17, 110))
            self.display.blit(self.selectButtonMid, (157, 110))
            self.display.blit(self.selectButtonRight, (297, 110))

            self.display.blit(self.zoom(self.elf.image, 3), (40, 95))
            self.display.blit(self.zoom(self.wizzard.image, 3), (180, 95))
            self.display.blit(self.zoom(self.knight.image, 3), (320, 95))



            self.display_flip()

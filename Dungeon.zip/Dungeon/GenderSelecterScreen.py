import pygame
import Scene
from Game import Game
from ElfM import ElfM
from WizzardM import WizzardM
from KnightM import KnightM
from ElfF import ElfF
from WizzardF import WizzardF
from KnightF import KnightF

class GenderSelecterScreen(Scene.Scene):

    def __init__(self, screen):
        super().__init__(screen)

        self.selectButtonLeft = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonBlack.png')
        self.selectButtonRight = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonBlack.png')

        self.selectButtonLeftRect = pygame.Rect(16, 90, 112, 112)
        self.selectButtonRightRect = pygame.Rect(308, 90, 112, 112)

        self.back = pygame.image.load('assets/textures/gui/SelectTypeScreen/back.png')

        self.elf_m = ElfM()
        self.elf_f = ElfF()
        self.wizzard_m = WizzardM()
        self.wizzard_f = WizzardF()
        self.knight_m = KnightM()
        self.knight_f = KnightF()
        self.hero_past_string = None
        self.hero_string = None

        self.xPos = [40, 330]
        self.yPos = [75, 75]


        self.started = False


    def handling_event(self):

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if self.selectButtonLeftRect.collidepoint(self.mousePos):
                self.selectButtonLeft = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonWhite.png')
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.hero_string = f'{self.hero_past_string}_f'
                    self.started = True
            elif self.selectButtonRightRect.collidepoint(self.mousePos):
                self.selectButtonRight = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonWhite.png')
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.hero_string = f'{self.hero_past_string}_m'
                    self.started = True
            else:
                self.selectButtonLeft = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonBlack.png')
                self.selectButtonRight = pygame.image.load('assets/textures/gui/SelectTypeScreen/selectButtonBlack.png')

        self.clock.tick(120)


    def update(self):
        self.elf_m.update()
        self.elf_f.update()
        self.wizzard_m.update()
        self.wizzard_f.update()
        self.knight_m.update()
        self.knight_f.update()

        if self.started:
            self.start()

    def start(self):
        start_Rect = pygame.Rect(0, 215, 426, 16)
        down_rect = pygame.Rect(0, 0, 426, 25)

        if self.hero_string == 'elf_m':
            hero = self.elf_m
            if down_rect.collidepoint(self.xPos[1], self.yPos[1]):
                hero.momentum = -hero.momentum - 2.5
            else:
                hero.momentum += 0.1
            self.yPos[1] -= hero.momentum

            if start_Rect.collidepoint(self.xPos[1], self.yPos[1]):
                self.running = False
                hero.momentum = 0
                Game(self.display, hero).run()
        if self.hero_string == 'elf_f':
            hero = self.elf_f
            if down_rect.collidepoint(self.xPos[0], self.yPos[0]):
                hero.momentum = -hero.momentum - 2.5
            else:
                hero.momentum += 0.1
            self.yPos[0] -= hero.momentum

            if start_Rect.collidepoint(self.xPos[1], self.yPos[1]):
                self.running = False
                hero.momentum = 0
                Game(self.display, hero).run()
        if self.hero_string == 'wizzard_m':
            hero = self.wizzard_m
            if down_rect.collidepoint(self.xPos[1], self.yPos[1]):
                hero.momentum = -hero.momentum - 2.5
            else:
                hero.momentum += 0.1
            self.yPos[1] -= hero.momentum

            if start_Rect.collidepoint(self.xPos[1], self.yPos[1]):
                self.running = False
                hero.momentum = 0
                Game(self.display, hero).run()
        if self.hero_string == 'wizzard_f':
            hero = self.wizzard_f
            if down_rect.collidepoint(self.xPos[0], self.yPos[0]):
                hero.momentum = -hero.momentum - 2.5
            else:
                hero.momentum += 0.1
            self.yPos[0] -= hero.momentum

            if start_Rect.collidepoint(self.xPos[1], self.yPos[1]):
                self.running = False
                hero.momentum = 0
                Game(self.display, hero).run()
        if self.hero_string == 'knight_m':
            hero = self.knight_m
            if down_rect.collidepoint(self.xPos[1], self.yPos[1]):
                hero.momentum = -hero.momentum - 2.5
            else:
                hero.momentum += 0.1
            self.yPos[1] -= hero.momentum

            if start_Rect.collidepoint(self.xPos[1], self.yPos[1]):
                self.running = False
                hero.momentum = 0
                Game(self.display, hero).run()
        if self.hero_string == 'knight_f':
            hero = self.knight_f
            if down_rect.collidepoint(self.xPos[0], self.yPos[0]):
                hero.momentum = -hero.momentum - 2.5
            else:
                hero.momentum += 0.1
            self.yPos[0] -= hero.momentum

            if start_Rect.collidepoint(self.xPos[1], self.yPos[1]):
                self.running = False
                hero.momentum = 0
                Game(self.display, hero).run()


    def load_hero(self, hero):
        if hero == 'elf':
            self.display.blit(self.zoom(self.elf_f.image, 3), (self.xPos[0], self.yPos[0]))
            self.display.blit(self.zoom(self.elf_m.image, 3), (self.xPos[1], self.yPos[1]))
            self.hero_past_string = 'elf'
        elif hero == 'wizzard':
            self.display.blit(self.zoom(self.wizzard_f.image, 3), (self.xPos[0], self.yPos[0]))
            self.display.blit(self.zoom(self.wizzard_m.image, 3), (self.xPos[1], self.yPos[1]))
            self.hero_past_string = 'wizzard'
        elif hero == 'knight':
            self.display.blit(self.zoom(self.knight_f.image, 3), (self.xPos[0], self.yPos[0]))
            self.display.blit(self.zoom(self.knight_m.image, 3), (self.xPos[1], self.yPos[1]))
            self.hero_past_string = 'knight'





    def run(self, hero):
        while self.running:
            self.handling_event()
            self.update()

            self.screen.fill((34, 34, 34))
            self.display.fill((0, 0, 0))

            self.display.blit(self.back, (0, 0))
            self.display.blit(self.selectButtonLeft, (16, 90))
            self.display.blit(self.selectButtonRight, (308, 90))

            self.load_hero(hero)


            self.display_flip()

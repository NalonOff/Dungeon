import pygame
from Map import Map
from Skelet import Skelet
from Wogol import Wogol
from Goblin import Goblin
from Zombie import Zombie
from Chort import Chort

class Game:
    def __init__(self, screen):
        self.screen = screen
        self.display = pygame.Surface((426, 240))
        self.running = True
        self.clock = pygame.time.Clock()

        self.skelet = Skelet()
        self.wogol = Wogol()
        self.goblin = Goblin()
        self.zombie = Zombie()
        self.chort = Chort()

        self.map = Map()

    def handling_event(self):

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                pygame.quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    self.skelet.moving_left = True
                if event.key == pygame.K_d:
                    self.skelet.moving_right = True
                if event.key == pygame.K_s:
                    self.skelet.moving_down = True
                if event.key == pygame.K_w:
                    self.skelet.moving_up = True


            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    self.skelet.moving_left = False
                if event.key == pygame.K_d:
                    self.skelet.moving_right = False
                if event.key == pygame.K_s:
                    self.skelet.moving_down = False
                if event.key == pygame.K_w:
                    self.skelet.moving_up = False

        self.clock.tick(120)

    def update(self):
        self.skelet.update()
        self.wogol.update()
        self.goblin.update()
        self.zombie.update()
        self.chort.update()


    def run(self):
        while self.running:
            self.handling_event()
            self.update()

            self.screen.fill((34, 34, 34))
            self.display.fill((0, 0, 0))

            print(self.skelet.rect)

            self.map.renderLevel(self.map.loadLevel('map'), self.display)
            self.display.blit(self.skelet.image, self.skelet.pos)
            self.display.blit(self.wogol.image, self.wogol.pos)
            self.display.blit(self.goblin.image, self.goblin.pos)
            self.display.blit(self.zombie.image, self.zombie.pos)
            self.display.blit(self.chort.image, self.chort.pos)

            self.surf = pygame.transform.scale(self.display, (1024, 576))
            self.screen.blit(self.surf, (0, 0))

            pygame.display.flip()



import pygame
import Scene
from Map import Map
from ElfM import ElfM
from ElfF import ElfF
from WizzardM import WizzardM
from WizzardF import WizzardF
from KnightM import KnightM
from KnightF import KnightF

class Game(Scene.Scene):
    def __init__(self, screen):
        super().__init__(screen)

        self.elf_m = ElfM()
        self.elf_f = ElfF()
        self.wizzard_m = WizzardM()
        self.wizzard_f = WizzardF()
        self.knight_m = KnightM()
        self.knight_f = KnightF()

        self.map = Map()


    def handling_event(self):

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    self.hero.moving_left = True
                if event.key == pygame.K_d:
                    self.hero.moving_right = True
                if event.key == pygame.K_s:
                    self.hero.moving_down = True
                if event.key == pygame.K_w:
                    self.hero.moving_up = True

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    self.hero.moving_left = False
                if event.key == pygame.K_d:
                    self.hero.moving_right = False
                if event.key == pygame.K_s:
                    self.hero.moving_down = False
                if event.key == pygame.K_w:
                    self.hero.moving_up = False

        self.clock.tick(120)


    def run(self):
        while self.running:
            self.handling_event()
            self.hero.update()

            self.screen.fill((34, 34, 34))
            self.display.fill((0, 0, 0))

            self.map.renderLevel(self.map.loadLevel('map'), self.display)

            self.display_flip()
